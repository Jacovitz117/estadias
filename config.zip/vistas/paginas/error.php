<!-- Begin page -->
<div class="accountbg"></div>
<div class="wrapper-page">
    <div class="display-table">
        <div class="display-table-cell">
            <diV class="container">
                <div class="row">
                    <div class="col-md-6">
                        <img src="assets/images/extra.png" alt="" class="img-fluid">
                    </div>
                    <div class="col-md-6">
                        <div class="card">
                            <div class="card-block">
            
                                <div class="ex-page-content text-center">
                                    <h1 class="">404!</h1>
                                    <h3 class="text-primary">Lo sentimos, esta pagina no se encuentra disponible</h3><br>
            
                                    <a class="btn btn-raised btn-primary mb-5 waves-effect waves-light" href="home">Regresar a Inicio</a>
                                </div>
            
                            </div>
                        </div>
                    </div>
                </div>
            </diV>
        </div>
    </div>
</div>