/*
 Template Name: Urora - Bootstrap 4 Admin Dashboard
 Author: Mannatthemes
 Website: www.mannatthemes.com
 File: upload. Js
 */


!function($) {
    "use strict";
        $('form').parsley();
    }
(window.jQuery);




